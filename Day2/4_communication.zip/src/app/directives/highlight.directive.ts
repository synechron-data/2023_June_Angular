import { Directive, ElementRef, HostListener, Input, Renderer2 } from '@angular/core';

@Directive({
  selector: '[highlight]'
})
export class HighlightDirective {
  @Input('highlight') highlightColor: string;

  constructor(private element: ElementRef<HTMLElement>, private renderer: Renderer2) {
    this.highlightColor = 'yellow';
  }

  @HostListener('mouseenter')
  onMouseEnter() {
    this.renderer.setStyle(this.element.nativeElement, 'background-color', this.highlightColor);
  }

  @HostListener('mouseleave')
  onMouseLeave() {
    this.renderer.removeStyle(this.element.nativeElement, 'background-color');
  }
}