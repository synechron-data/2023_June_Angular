import { Component, HostBinding, OnDestroy, OnInit } from '@angular/core';
import { fadeInAnimation } from 'src/app/utilities/animations/fade-in.animation';
import { Product } from '../../models/product.model';
import { Subscription } from 'rxjs';
import { ItemsService } from '../../services/items.service';
import { PublisherService } from '../../services/publisher.service';

@Component({
  selector: 'crud-root',
  templateUrl: './crud-root.component.html',
  animations: [fadeInAnimation]
})
export class CrudRootComponent implements OnInit, OnDestroy {
  @HostBinding('@fadeInAnimation') fadeInAnimation = true;
  @HostBinding('style.display') display = 'block';

  products?: Array<Product>;
  message?: string;
  subscription?: Subscription;
  gap_subscription?: Subscription;
  dp_subscription?: Subscription;

  constructor(private itemsService: ItemsService, private pubService: PublisherService) { }

  ngOnInit(): void {
    this.subscription = this.pubService.on('products-updated').subscribe(() => this.loadProducts());
    this.loadProducts();
  }

  private loadProducts() {
    this.gap_subscription = this.itemsService.getAllProducts().subscribe({
      next: (products: Array<Product>) => {
        this.products = products;
        this.message = "";
      },
      error: (err: string) => {
        this.message = err;
      }
    });
  }

  deleteProduct(productId: number) {
    if (window.confirm("Are you sure to delete the product?")) {
      this.dp_subscription = this.itemsService.deleteProduct(productId).subscribe({
        next: () => {
          this.products = this.products?.filter(p => p.id !== productId);
        }
      });
    }
  }

  ngOnDestroy(): void {
    this.subscription?.unsubscribe();
    this.gap_subscription?.unsubscribe();
    this.dp_subscription?.unsubscribe();
  }
}
