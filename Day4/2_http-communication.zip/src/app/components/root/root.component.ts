// import { HttpClient, HttpErrorResponse } from '@angular/common/http';
// import { Component, OnDestroy, OnInit } from '@angular/core';
// import { Subscription } from 'rxjs';
// import { Post } from 'src/app/models/post.model';

// @Component({
//   selector: 'app-root',
//   templateUrl: './root.component.html'
// })
// export class RootComponent implements OnInit, OnDestroy {
//   url: string = 'https://jsonplaceholder.typicode.com/posts';
//   message: string = 'Loading Data, please wait...';
//   posts?: Array<Post>;
//   get_sub?: Subscription;

//   constructor(private httpClient: HttpClient) { }

//   ngOnInit(): void {
//     this.get_sub = this.httpClient.get<Array<Post>>(this.url).subscribe({
//       next: resData => {
//         this.posts = resData;
//         this.message = '';
//       },
//       error: (err: HttpErrorResponse) => {
//         this.message = err.message;
//       }
//     });
//   }

//   ngOnDestroy(): void {
//     this.get_sub?.unsubscribe();
//   }
// }

// -----------------------------------------

// import { HttpErrorResponse } from '@angular/common/http';
// import { Component, OnDestroy, OnInit } from '@angular/core';
// import { Subscription } from 'rxjs';
// import { Post } from 'src/app/models/post.model';
// import { PostService } from 'src/app/service/post.service';

// @Component({
//   selector: 'app-root',
//   templateUrl: './root.component.html',
//   // providers: [PostService]
// })
// export class RootComponent implements OnInit, OnDestroy {
//   message: string = 'Loading Data, please wait...';
//   posts?: Array<Post>;
//   get_sub?: Subscription;

//   constructor(private postService: PostService) { }

//   ngOnInit(): void {
//     this.get_sub = this.postService.getAllPosts().subscribe({
//       next: resData => {
//         this.posts = resData;
//         this.message = '';
//       },
//       error: (err: HttpErrorResponse) => {
//         this.message = err.message;
//       }
//     });
//   }

//   ngOnDestroy(): void {
//     this.get_sub?.unsubscribe();
//   }
// }

// -----------------------------------------

import { Component, OnDestroy, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { Post } from 'src/app/models/post.model';
import { PostService } from 'src/app/service/post.service';

@Component({
  selector: 'app-root',
  templateUrl: './root.component.html'
})
export class RootComponent implements OnInit, OnDestroy {
  message: string = 'Loading Data, please wait...';
  posts?: Array<Post>;
  get_sub?: Subscription;

  constructor(private postService: PostService) { }

  ngOnInit(): void {
    this.get_sub = this.postService.getAllPosts().subscribe({
      next: resData => {
        this.posts = resData;
        this.message = '';
      },
      error: (err: string) => {
        this.message = err;
      }
    });
  }

  deletePost(id: number, e: Event) {
    e.preventDefault();

    this.message = `Deleting a record with id: ${id}...`;

    this.postService.deletePost(id).subscribe({
      next: () => {
        this.posts = this.posts?.filter(p => p.id !== id);
        this.message = `Record with id: ${id} deleted successfully!`;
        setTimeout(() => {
          this.message = '';
        }, 3000);
      },
      error: (err: string) => {
        this.message = err;
      }
    });
  }

  ngOnDestroy(): void {
    this.get_sub?.unsubscribe();
  }
}