import { Component } from "@angular/core";

@Component({
    selector: 'app-hello',
    template: `
        <h1>
            Hello World from Angular!
        </h1>
    `
})
export class HelloComponent { }