/*
 * Public API Surface of manish-sync-pnq-jun23
 */

export * from './lib/manish-sync-pnq-jun23.service';
export * from './lib/manish-sync-pnq-jun23.component';
export * from './lib/manish-sync-pnq-jun23.module';
