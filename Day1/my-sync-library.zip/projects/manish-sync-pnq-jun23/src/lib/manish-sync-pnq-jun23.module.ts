import { NgModule } from '@angular/core';
import { ManishSyncPnqJun23Component } from './manish-sync-pnq-jun23.component';



@NgModule({
  declarations: [
    ManishSyncPnqJun23Component
  ],
  imports: [
  ],
  exports: [
    ManishSyncPnqJun23Component
  ]
})
export class ManishSyncPnqJun23Module { }
