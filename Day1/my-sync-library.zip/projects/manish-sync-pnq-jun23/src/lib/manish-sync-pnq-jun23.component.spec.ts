import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ManishSyncPnqJun23Component } from './manish-sync-pnq-jun23.component';

describe('ManishSyncPnqJun23Component', () => {
  let component: ManishSyncPnqJun23Component;
  let fixture: ComponentFixture<ManishSyncPnqJun23Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ManishSyncPnqJun23Component ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ManishSyncPnqJun23Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
