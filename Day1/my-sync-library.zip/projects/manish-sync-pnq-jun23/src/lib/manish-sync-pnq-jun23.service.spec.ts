import { TestBed } from '@angular/core/testing';

import { ManishSyncPnqJun23Service } from './manish-sync-pnq-jun23.service';

describe('ManishSyncPnqJun23Service', () => {
  let service: ManishSyncPnqJun23Service;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ManishSyncPnqJun23Service);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
