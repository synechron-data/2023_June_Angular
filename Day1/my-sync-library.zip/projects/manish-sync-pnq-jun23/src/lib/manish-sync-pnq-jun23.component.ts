import { Component } from '@angular/core';

@Component({
  selector: 'lib-manish-sync-pnq-jun23',
  template: `
    <h3 class="text-center text-primary">
      manish-sync-pnq-jun23 works!
    </h3>
  `,
  styles: [
  ]
})
export class ManishSyncPnqJun23Component {

}
