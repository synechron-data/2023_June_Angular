import { Component } from '@angular/core';

@Component({
  selector: 'app-hello',
  template: `
    <h2 class="text-info">
      Hello from Module Two
    </h2>
  `,
  styles: [
  ]
})
export class HelloComponent {

}
