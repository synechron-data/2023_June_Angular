import { Component } from '@angular/core';

@Component({
  selector: 'app-scomp',
  template: `
    <h3 class="text-danger">I am the Shared Component from Shared Module</h3>
  `,
  styles: [
  ]
})
export class ScompComponent {

}
