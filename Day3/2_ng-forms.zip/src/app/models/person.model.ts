export interface Person {
    firstname: string;
    lastname: string;
    address: {
        city: string;
        zip: string;
    };
}