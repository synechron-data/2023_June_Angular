import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { CustomValidators } from 'src/app/utilities/validators/custom-validators';

@Component({
  selector: 'validation-form',
  templateUrl: './validation-form.component.html'
})
export class ValidationFormComponent {
  regForm: FormGroup;

  countries = [
    { 'id': "", 'name': 'Select Country' },
    { 'id': 1, 'name': 'India' },
    { 'id': 2, 'name': 'USA' },
    { 'id': 3, 'name': 'UK' }
  ];

  minAge = 20;
  maxAge = 60;

  constructor(private frmBuilder: FormBuilder) {
    this.regForm = this.frmBuilder.group({
      firstname: ['', Validators.required],
      lastname: ['', Validators.compose([
        Validators.required,
        Validators.minLength(2),
        Validators.maxLength(6)
      ])],
      gender: ['', Validators.required],
      age: ['', [
        Validators.required,
        // CustomValidators.ageRange
        CustomValidators.ageRange(this.minAge, this.maxAge)
      ]],
      address: this.frmBuilder.group({
        country: ['', Validators.required],
        city: ['', Validators.required],
        zip: ['', Validators.required],
        fulladdress: ['', Validators.required],
      }),
      acceptTerms: ['', Validators.requiredTrue],
    });
  }

  logForm() {
    if (this.regForm.valid) {
      // Code to submit form via API call
      console.log(this.regForm.value);
    } else {
      console.error("Form is invalid");
      this.regForm.markAllAsTouched();
    }
  }

  reset() {
    this.regForm.reset();
  }

  get frm() { return this.regForm.controls; }
  get address() { return (this.regForm.controls['address'] as FormGroup).controls; }
}

// -------------------------------------------------- Using Model
// import { Component } from '@angular/core';
// import { FormGroup, FormBuilder, Validators } from '@angular/forms';
// import { Person } from 'src/app/models/person.model';

// @Component({
//   selector: 'validation-form',
//   templateUrl: './validation-form.component.html'
// })
// export class ValidationFormComponent {
//   regForm: FormGroup;

//   person: Person = {
//     firstname: "",
//     lastname: "",
//     address: {
//       city: "",
//       zip: ""
//     }
//   };

//   constructor(private frmBuilder: FormBuilder) {
//     this.regForm = this.personToFormGroup(this.person);
//   }

//   private personToFormGroup(person: Person): FormGroup {
//     return this.frmBuilder.group({
//       firstname: [person.firstname, Validators.required],
//       lastname: [person.lastname, Validators.compose([
//         Validators.required,
//         Validators.minLength(2),
//         Validators.maxLength(6)
//       ])],
//       address: this.frmBuilder.group({
//         city: [person.address.city, Validators.required],
//         zip: [person.address.zip, Validators.required]
//       })
//     });
//   }

//   logForm() {
//     if (this.regForm.valid) {
//       // Code to submit form via API call
//       const person = this.formGroupToPerson(this.regForm);
//       console.log(person);
//     } else {
//       console.error("Form is invalid");
//       this.regForm.markAllAsTouched();
//     }
//   }

//   private formGroupToPerson(formGroup: FormGroup): Person { 
//     return {
//       firstname: formGroup.controls['firstname'].value,
//       lastname: formGroup.controls['lastname'].value,
//       address: {
//         city: formGroup.controls['address'].value['city'],
//         zip: formGroup.controls['address'].value['zip']
//       }
//     };
//   }

//   reset() {
//     this.regForm.reset();
//   }

//   get frm() { return this.regForm.controls; }
//   get address() { return (this.regForm.controls['address'] as FormGroup).controls; }
// }
